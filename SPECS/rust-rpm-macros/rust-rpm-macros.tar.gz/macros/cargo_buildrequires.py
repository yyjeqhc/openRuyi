#!/usr/bin/env python3
"""
Generate BuildRequires for Rust projects from Cargo.lock

This script parses Cargo.lock, extracts all dependencies from crates.io,
checks which ones are already installed in the system cargo registry,
and outputs RPM-style crate() dependencies.

Usage:
    %generate_buildrequires
    %cargo_buildrequires
"""

import sys
import os
import argparse
import traceback
import pathlib
import re
from collections import defaultdict

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        print("Error: tomllib or tomli is required", file=sys.stderr)
        sys.exit(1)


class EndPass(Exception):
    """End current pass of generating requirements"""
    pass


def print_err(*args, **kwargs):
    """Print to stderr"""
    kwargs.setdefault('file', sys.stderr)
    print(*args, **kwargs)


def normalize_crate_name(name):
    """Normalize crate name (replace - with _, lowercase)"""
    return name.replace('-', '_').lower()


def extract_major_minor_version(version_str):
    """
    Extract major.minor version from full version string.
    
    Examples:
        '0.17.3' -> '0.17'
        '1.2.3' -> '1.2'
        '2.0.85' -> '2.0'
    """
    parts = version_str.split('.')
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}"
    return version_str


def parse_version_spec(version_str):
    """
    Parse Cargo version specification into RPM-style operators.
    Cargo uses semver-compatible specs.
    """
    version_str = version_str.strip()
    
    # Handle simple version: "1.0.0" means "^1.0.0"
    if version_str[0].isdigit():
        return [('', version_str)]
    
    # Handle caret requirement: "^1.2.3"
    if version_str.startswith('^'):
        version = version_str[1:]
        return [('', version)]
    
    # Handle tilde requirement: "~1.2.3" or "~=1.2.3"
    if version_str.startswith('~=') or version_str.startswith('~'):
        version = version_str[2:] if version_str.startswith('~=') else version_str[1:]
        return [('>=', version)]
    
    # Handle comparison operators
    if version_str.startswith('>='):
        return [('>=', version_str[2:].strip())]
    if version_str.startswith('<='):
        return [('<=', version_str[2:].strip())]
    if version_str.startswith('>'):
        return [('>', version_str[1:].strip())]
    if version_str.startswith('<'):
        return [('<', version_str[1:].strip())]
    if version_str.startswith('='):
        return [('=', version_str[1:].strip())]
    
    # Default: exact version
    return [('', version_str)]


def format_rpm_crate_dependency(crate_name, crate_version, source=''):
    """
    Format a crate dependency in RPM style.
    
    RPM naming convention:
    crate(name-MAJOR.MINOR/default) >= VERSION
    
    Examples:
    - serde 1.0.193 -> crate(serde-1.0/default) >= 1.0.193
    - syn 2.0.48 -> crate(syn-2.0/default) >= 2.0.48
    - tempfile 3.0.0 -> crate(tempfile-3.0/default) >= 3.0.0
    
    Note: For simplicity, we use 'default' as the feature placeholder
    to match the existing RPM packaging convention.
    """
    # Extract major.minor for RPM naming
    major_minor = extract_major_minor_version(crate_version)
    
    # Format: name-MAJOR.MINOR
    rpm_crate_name = f"{crate_name}-{major_minor}"
    
    # Build the crate() dependency string
    dep_name = f"crate({rpm_crate_name}/default)"
    dep_full = f"{dep_name} >= {crate_version}"
    
    return dep_name, dep_full


def check_crate_installed_in_registry(crate_name, crate_version, registry_path='/usr/share/cargo/registry'):
    """
    Check if a crate is installed in the system cargo registry.
    
    The check is flexible on patch version:
    - Looking for: tempfile-3.0.0
    - Will match:  tempfile-3.0-* (any patch version)
    
    This matches the RPM packaging convention where we package
    crate-name-MAJOR.MINOR-*
    
    Returns:
        - True if installed (matching major.minor)
        - False if not installed
    """
    registry = pathlib.Path(registry_path)
    
    if not registry.exists():
        return False
    
    # Extract major.minor version for flexible matching
    major_minor = extract_major_minor_version(crate_version)
    
    # Look for crate directory: crate_name-MAJOR.MINOR-*/
    # Pattern: name-version_pattern*
    crate_name_normalized = normalize_crate_name(crate_name)
    version_prefix = f"{crate_name}-{major_minor}"
    
    for d in registry.iterdir():
        if d.is_dir():
            dir_name = d.name
            # Check if directory starts with name-version_pattern
            if dir_name.startswith(version_prefix):
                # Verify the crate name matches (normalize both)
                dir_crate_name = dir_name.rsplit('-', 2)[0]  # Get name part
                if normalize_crate_name(dir_crate_name) == crate_name_normalized:
                    return True
    
    return False


def load_cargo_lock():
    """Load and parse Cargo.lock"""
    try:
        with open('Cargo.lock', 'rb') as f:
            return tomllib.load(f)
    except FileNotFoundError:
        print_err("Error: Cargo.lock not found")
        print_err("Hint: Run 'cargo generate-lockfile' or 'cargo update' to generate it")
        sys.exit(1)


def extract_dependencies_from_lock(cargo_lock_data, include_dev=True, include_build=True):
    """
    Extract all dependencies from Cargo.lock.
    
    Cargo.lock contains a [[package]] array with all resolved dependencies.
    We need to filter out path dependencies and only include crates.io packages.
    
    Returns list of (crate_name, version, source) tuples
    """
    deps = []
    
    packages = cargo_lock_data.get('package', [])
    if not packages:
        print_err("Warning: No packages found in Cargo.lock")
        return deps
    
    for package in packages:
        name = package.get('name')
        version = package.get('version')
        source = package.get('source', '')
        
        # Skip if name or version is missing
        if not name or not version:
            continue
        
        # Only include crates.io dependencies
        # crates.io packages have source like:
        # "registry+https://github.com/rust-lang/crates.io-index"
        # Path dependencies have source like:
        # "file:///path/to/local/crate"
        # We want to include all crates.io packages and exclude path deps
        
        if source and source.startswith('file://'):
            # Skip local path dependencies
            print_err(f"Skipping local dependency: {name} {version} ({source})")
            continue
        
        # Include this dependency
        deps.append((name, version, source))
    
    return deps


def generate_buildrequires(
    output_file=None,
    include_dev=True,
    include_build=True,
    registry_path='/usr/share/cargo/registry',
):
    """
    Main function to generate BuildRequires from Cargo.lock.
    
    This is the main entry point, similar to generate_requires in pyproject_buildrequires.py
    """
    cargo_lock_data = load_cargo_lock()
    
    output_lines = []
    missing_requirements = False
    
    # Add basic Rust toolchain requirements
    output_lines.append('rust')
    output_lines.append('cargo')
    
    # Extract all dependencies from Cargo.lock
    deps = extract_dependencies_from_lock(cargo_lock_data, include_dev, include_build)
    
    print_err(f"\nFound {len(deps)} dependencies in Cargo.lock\n")
    
    # Process each dependency
    for crate_name, crate_version, source in deps:
        # Check if crate is installed in system registry
        is_installed = check_crate_installed_in_registry(
            crate_name, crate_version, registry_path
        )
        
        # Format the RPM dependency
        dep_name, dep_full = format_rpm_crate_dependency(
            crate_name, crate_version, source
        )
        
        # Output dependency status
        if is_installed:
            print_err(f'✓ Requirement satisfied: {crate_name}-{crate_version} (installed)')
        else:
            print_err(f'✗ Requirement not satisfied: {crate_name}-{crate_version}')
            missing_requirements = True
        
        # Add to output
        output_lines.append(dep_full)
    
    # Write output
    if output_file:
        output_path = pathlib.Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text('\n'.join(output_lines) + '\n')
        print_err(f"\nGenerated BuildRequires written to: {output_file}")
    
    # If missing requirements, signal to RPM for bootstrap cycle
    if missing_requirements:
        print_err('\n⚠ Missing dependencies detected - triggering OBS bootstrap cycle')
        raise EndPass('missing crates')
    else:
        print_err('\n✓ All dependencies satisfied')
    
    return output_lines


def main(argv):
    parser = argparse.ArgumentParser(
        description='Generate BuildRequires for a Rust/Cargo project from Cargo.lock.',
        prog='%cargo_buildrequires',
    )
    parser.add_argument(
        '-d', '--dev', action='store_true', default=True,
        help='Include dev-dependencies (default: true, all deps from Cargo.lock are included)',
    )
    parser.add_argument(
        '-b', '--build', action='store_true', default=True,
        help='Include build-dependencies (default: true, all deps from Cargo.lock are included)',
    )
    parser.add_argument(
        '--registry', type=str, default='/usr/share/cargo/registry',
        help='Path to system cargo registry (default: /usr/share/cargo/registry)',
    )
    parser.add_argument(
        '--output', type=str, required=True,
        help='Output file for generated BuildRequires',
    )
    
    args = parser.parse_args(argv)
    
    try:
        generate_buildrequires(
            output_file=args.output,
            include_dev=args.dev,
            include_build=args.build,
            registry_path=args.registry,
        )
    except EndPass:
        # Expected exception for missing dependencies - triggers OBS bootstrap
        sys.exit(0)
    except Exception:
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main(sys.argv[1:])
