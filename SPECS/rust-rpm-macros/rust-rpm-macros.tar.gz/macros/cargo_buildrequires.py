#!/usr/bin/env python3
"""
Generate BuildRequires for Rust projects from Cargo.lock

This script parses Cargo.lock, extracts all dependencies from crates.io,
checks which ones are already installed in the system cargo registry,
and outputs RPM-style crate() dependencies.

Usage:
    %generate_buildrequires
    %cargo_buildrequires
"""

import sys
import os
import argparse
import traceback
import pathlib
import re
from collections import defaultdict

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        print("Error: tomllib or tomli is required", file=sys.stderr)
        sys.exit(1)


class EndPass(Exception):
    """End current pass of generating requirements"""
    pass


def print_err(*args, **kwargs):
    """Print to stderr"""
    kwargs.setdefault('file', sys.stderr)
    print(*args, **kwargs)


def normalize_crate_name(name):
    """Normalize crate name (replace - with _, lowercase)"""
    return name.replace('-', '_').lower()


def extract_major_minor_version(version_str):
    """
    Extract major.minor version from full version string.
    
    Examples:
        '0.17.3' -> '0.17'
        '1.2.3' -> '1.2'
        '2.0.85' -> '2.0'
    """
    parts = version_str.split('.')
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}"
    return version_str


def parse_version_spec(version_str):
    """
    Parse Cargo version specification into RPM-style operators.
    Cargo uses semver-compatible specs.
    """
    version_str = version_str.strip()
    
    # Handle simple version: "1.0.0" means "^1.0.0"
    if version_str[0].isdigit():
        return [('', version_str)]
    
    # Handle caret requirement: "^1.2.3"
    if version_str.startswith('^'):
        version = version_str[1:]
        return [('', version)]
    
    # Handle tilde requirement: "~1.2.3" or "~=1.2.3"
    if version_str.startswith('~=') or version_str.startswith('~'):
        version = version_str[2:] if version_str.startswith('~=') else version_str[1:]
        return [('>=', version)]
    
    # Handle comparison operators
    if version_str.startswith('>='):
        return [('>=', version_str[2:].strip())]
    if version_str.startswith('<='):
        return [('<=', version_str[2:].strip())]
    if version_str.startswith('>'):
        return [('>', version_str[1:].strip())]
    if version_str.startswith('<'):
        return [('<', version_str[1:].strip())]
    if version_str.startswith('='):
        return [('=', version_str[1:].strip())]
    
    # Default: exact version
    return [('', version_str)]


def format_rpm_crate_dependency(crate_name, crate_version, source=''):
    """
    Format a crate dependency in RPM style.

    RPM naming convention:
    crate(name) = VERSION

    We use the exact version from Cargo.lock. The crate package should
    provide: crate(name) = version

    Each crate version is treated as a separate entity. If Cargo.lock
    requires multiple versions of the same crate, all of them must be
    available in the system.

    Examples:
    - anstream 0.6.19 -> crate(anstream) = 0.6.19
    - clap 4.5.41 -> crate(clap) = 4.5.41
    - serde 1.0.193 -> crate(serde) = 1.0.193
    """
    # Normalize crate name: replace _ with -
    normalized_name = crate_name.replace('_', '-')

    # Use exact version from Cargo.lock
    dep_full = f"crate({normalized_name}) = {crate_version}"

    return f"crate({normalized_name})", dep_full


def extract_major_version(version_str):
    """
    Extract major version from full version string.

    Examples:
        '0.17.3' -> '0.17'
        '1.2.3' -> '1'
        '2.0.85' -> '2'
    """
    parts = version_str.split('.')
    if len(parts) >= 1:
        major = parts[0]
        # For 0.x versions, include minor (0.x is unstable, minor can break)
        # For 1.x+ versions, match major only (semver compatible)
        if major == '0' and len(parts) >= 2:
            return f"{major}.{parts[1]}"
        return major
    return version_str


def check_crate_installed_in_registry(crate_name, crate_version, registry_path='/usr/share/cargo/registry'):
    """
    Check if a crate is installed in the system cargo registry.

    This function looks for a directory in the format 'name-version' where
    'version' is a semantic version number. It ensures we don't mistakenly
    match different crates with similar name prefixes (e.g., 'clap' vs 'clap-derive').

    Note: The registry directory names use the original crate name format
    (with underscores if present), not normalized (with hyphens).

    The check verifies that:
    1. Directory name starts with 'crate_name-'
    2. What follows 'crate_name-' looks like a version number (starts with digit)

    Examples:
    - Looking for: clap 4.5.13 -> matches 'clap-4.5.13' or 'clap-4.6.0'
      (but NOT 'clap-derive-4.5.13' because 'derive' is not a version)
    - Looking for: serde_derive 1.0.0 -> matches 'serde_derive-1.0.0'
      (registry uses original name with underscore)

    Returns:
        - True if installed (matching directory found)
        - False if not installed
    """
    registry = pathlib.Path(registry_path)

    if not registry.exists():
        return False

    # Build prefix to look for: name- (use original name from Cargo.lock)
    # Registry uses original format, not normalized
    expected_prefix = f"{crate_name}-"

    for d in registry.iterdir():
        if d.is_dir():
            dir_name = d.name
            # Check if directory name starts with expected prefix
            if dir_name.startswith(expected_prefix):
                # Get what comes after the prefix
                remainder = dir_name[len(expected_prefix):]
                # Check if remainder starts with a digit (indicating it's a version)
                # This prevents matching 'clap-derive-4.5.13' when looking for 'clap'
                if remainder and remainder[0].isdigit():
                    return True

    return False


def load_cargo_lock():
    """Load and parse Cargo.lock"""
    try:
        with open('Cargo.lock', 'rb') as f:
            return tomllib.load(f)
    except FileNotFoundError:
        print_err("Error: Cargo.lock not found")
        print_err("Hint: Run 'cargo generate-lockfile' or 'cargo update' to generate it")
        sys.exit(1)


def extract_dependencies_from_lock(cargo_lock_data, include_dev=True, include_build=True):
    """
    Extract all dependencies from Cargo.lock.
    
    Cargo.lock contains a [[package]] array with all resolved dependencies.
    We need to filter out path dependencies and only include crates.io packages.
    
    Returns list of (crate_name, version, source) tuples
    """
    deps = []
    
    packages = cargo_lock_data.get('package', [])
    if not packages:
        print_err("Warning: No packages found in Cargo.lock")
        return deps
    
    for package in packages:
        name = package.get('name')
        version = package.get('version')
        source = package.get('source', '')
        
        # Skip if name or version is missing
        if not name or not version:
            continue
        
        # Only include crates.io dependencies
        # crates.io packages have source like:
        # "registry+https://github.com/rust-lang/crates.io-index"
        # Path dependencies have source like:
        # "file:///path/to/local/crate"
        # We want to include all crates.io packages and exclude path deps
        
        if source and source.startswith('file://'):
            # Skip local path dependencies
            print_err(f"Skipping local dependency: {name} {version} ({source})")
            continue
        
        # Include this dependency
        deps.append((name, version, source))
    
    return deps


def generate_buildrequires(
    output_file=None,
    include_dev=True,
    include_build=True,
    registry_path='/usr/share/cargo/registry',
):
    """
    Main function to generate BuildRequires from Cargo.lock.
    
    This is the main entry point, similar to generate_requires in pyproject_buildrequires.py
    """
    cargo_lock_data = load_cargo_lock()
    
    output_lines = []
    missing_requirements = False
    
    # Add basic Rust toolchain requirements
    output_lines.append('rust')
    output_lines.append('cargo')
    
    # Extract all dependencies from Cargo.lock
    deps = extract_dependencies_from_lock(cargo_lock_data, include_dev, include_build)
    
    print_err(f"\nFound {len(deps)} dependencies in Cargo.lock\n")
    
    # Process each dependency
    for crate_name, crate_version, source in deps:
        # Check if crate is installed in system registry
        is_installed = check_crate_installed_in_registry(
            crate_name, crate_version, registry_path
        )
        
        # Format the RPM dependency
        dep_name, dep_full = format_rpm_crate_dependency(
            crate_name, crate_version, source
        )
        
        # Output dependency status
        if is_installed:
            print_err(f'✓ Requirement satisfied: {crate_name}-{crate_version} (installed)')
        else:
            print_err(f'✗ Requirement not satisfied: {crate_name}-{crate_version}')
            missing_requirements = True
        
        # Add to output
        output_lines.append(dep_full)
    
    # Write output
    if output_file:
        output_path = pathlib.Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text('\n'.join(output_lines) + '\n')
        print_err(f"\nGenerated BuildRequires written to: {output_file}")
    
    # If missing requirements, signal to RPM for bootstrap cycle
    if missing_requirements:
        print_err('\n⚠ Missing dependencies detected - triggering OBS bootstrap cycle')
        raise EndPass('missing crates')
    else:
        print_err('\n✓ All dependencies satisfied')
    
    return output_lines


def main(argv):
    parser = argparse.ArgumentParser(
        description='Generate BuildRequires for a Rust/Cargo project from Cargo.lock.',
        prog='%cargo_buildrequires',
    )
    parser.add_argument(
        '-d', '--dev', action='store_true', default=True,
        help='Include dev-dependencies (default: true, all deps from Cargo.lock are included)',
    )
    parser.add_argument(
        '-b', '--build', action='store_true', default=True,
        help='Include build-dependencies (default: true, all deps from Cargo.lock are included)',
    )
    parser.add_argument(
        '--registry', type=str, default='/usr/share/cargo/registry',
        help='Path to system cargo registry (default: /usr/share/cargo/registry)',
    )
    parser.add_argument(
        '--output', type=str, required=True,
        help='Output file for generated BuildRequires',
    )
    
    args = parser.parse_args(argv)
    
    try:
        generate_buildrequires(
            output_file=args.output,
            include_dev=args.dev,
            include_build=args.build,
            registry_path=args.registry,
        )
    except EndPass:
        # Expected exception for missing dependencies - triggers OBS bootstrap
        sys.exit(0)
    except Exception:
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main(sys.argv[1:])
